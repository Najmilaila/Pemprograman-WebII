<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\latihan_penjualan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>